﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;

namespace ProductCatalogApp
{
    public class ProductCatalogDBContext : IDisposable
    {
        private SQLiteConnection _connection;

        public ProductCatalogDBContext()
        {
            _connection = new SQLiteConnection("Data Source=ProductCatalogDB.db");
            _connection.Open();


            using (var cmd = new SQLiteCommand("CREATE TABLE IF NOT EXISTS Products (Id INTEGER PRIMARY KEY, Name TEXT, Price REAL)", _connection))
            {
                cmd.ExecuteNonQuery();
            }


        }

       

        public void AddProduct(Product product)
        {
            using (var cmd = new SQLiteCommand("INSERT INTO Products (Name, Price) VALUES (@Name, @Price)", _connection))
            {
                cmd.Parameters.Add(new SQLiteParameter("@Name", product.Name));
                cmd.Parameters.Add(new SQLiteParameter("@Price", product.Price));
                cmd.ExecuteNonQuery();
            }
        }

        public void UpdateProduct(Product product)
        {
            using (var cmd = new SQLiteCommand("UPDATE Products SET Name = @Name, Price = @Price WHERE Id = @Id", _connection))
            {
                cmd.Parameters.Add(new SQLiteParameter("@Id", product.Id));
                cmd.Parameters.Add(new SQLiteParameter("@Name", product.Name));
                cmd.Parameters.Add(new SQLiteParameter("@Price", product.Price));
                cmd.ExecuteNonQuery();
            }
        }

        public void DeleteProduct(int productId)
        {
            using (var cmd = new SQLiteCommand("DELETE FROM Products WHERE Id = @Id", _connection))
            {
                cmd.Parameters.Add(new SQLiteParameter("@Id", productId));
                cmd.ExecuteNonQuery();
            }
        }

        public List<Product> GetAllProducts()
        {
            List<Product> products = new List<Product>();

            using (var cmd = new SQLiteCommand("SELECT * FROM Products", _connection))
            using (var reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    products.Add(new Product
                    {
                        Id = Convert.ToInt32(reader["Id"]),
                        Name = Convert.ToString(reader["Name"]),
                        Price = Convert.ToDouble(reader["Price"])
                    });
                }
            }

            return products;
        }

        public List<Product> SearchProducts(string searchTerm)
        {
            List<Product> products = new List<Product>();

            using (var cmd = new SQLiteCommand("SELECT * FROM Products WHERE Name LIKE @SearchTerm", _connection))
            {
                cmd.Parameters.Add(new SQLiteParameter("@SearchTerm", "%" + searchTerm + "%"));
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        products.Add(new Product
                        {
                            Id = Convert.ToInt32(reader["Id"]),
                            Name = Convert.ToString(reader["Name"]),
                            Price = Convert.ToDouble(reader["Price"])
                        });
                    }
                }
            }

            return products;
        }

        public void Dispose()
        {
            _connection.Close();
            _connection.Dispose();
        }
    }
}





