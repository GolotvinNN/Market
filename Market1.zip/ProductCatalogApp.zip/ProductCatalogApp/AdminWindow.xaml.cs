﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;

namespace ProductCatalogApp
{
    public partial class AdminWindow : Window
    {
        private ProductCatalogDBContext dbContext = new ProductCatalogDBContext();
        private List<Product> products = new List<Product>();

        public AdminWindow()
        {
            InitializeComponent();
            LoadProducts();
        }

        private void LoadProducts()
        {
            products = dbContext.GetAllProducts();
            RefreshProductList();
        }

        private void RefreshProductList()
        {
            ProductsListBox.ItemsSource = null;
            ProductsListBox.ItemsSource = products.Select(p => $"{p.Name} - {p.Price}");
        }

        private void AddProductButton_Click(object sender, RoutedEventArgs e)
        {
            string name = ProductNameTextBox.Text;
            if (string.IsNullOrWhiteSpace(name))
            {
                MessageBox.Show("Введите название товара.");
                return;
            }

            double price;
            if (!double.TryParse(ProductPriceTextBox.Text, out price))
            {
                MessageBox.Show("Введите корректную цену товара.");
                return;
            }

            Product newProduct = new Product { Name = name, Price = price };
            dbContext.AddProduct(newProduct);
            products.Add(newProduct);
            RefreshProductList();

            ProductNameTextBox.Text = "";
            ProductPriceTextBox.Text = "";
        }

        private void DeleteProductButton_Click(object sender, RoutedEventArgs e)
        {
            if (ProductsListBox.SelectedItem != null)
            {
                string selectedItem = ProductsListBox.SelectedItem.ToString();
                string[] parts = selectedItem.Split('-');
                string productName = parts[0].Trim();
                double productPrice = double.Parse(parts[1].Trim());

                Product productToDelete = products.FirstOrDefault(p => p.Name == productName && p.Price == productPrice);
                if (productToDelete != null)
                {
                    dbContext.DeleteProduct(productToDelete.Id);
                    products.Remove(productToDelete);
                    RefreshProductList();
                }
            }
            else
            {
                MessageBox.Show("Выберите товар для удаления.");
            }
        }

        private void UpdateProductButton_Click(object sender, RoutedEventArgs e)
        {
            if (ProductsListBox.SelectedItem != null)
            {
                string selectedItem = ProductsListBox.SelectedItem.ToString();
                string[] parts = selectedItem.Split('-');
                string productName = parts[0].Trim();
                double productPrice = double.Parse(parts[1].Trim());

                Product selectedProduct = products.FirstOrDefault(p => p.Name == productName && p.Price == productPrice);
                if (selectedProduct != null)
                {
                    string newName = ProductNameTextBox.Text;
                    double newPrice;
                    if (!string.IsNullOrWhiteSpace(newName) && double.TryParse(ProductPriceTextBox.Text, out newPrice))
                    {
                        selectedProduct.Name = newName;
                        selectedProduct.Price = newPrice;
                        dbContext.UpdateProduct(selectedProduct);
                        RefreshProductList();
                    }
                    else
                    {
                        MessageBox.Show("Введите корректные данные для обновления товара.");
                    }
                }
            }
            else
            {
                MessageBox.Show("Выберите товар для обновления.");
            }
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            dbContext.Dispose();
            LoginWindow loginWindow = new LoginWindow();
            loginWindow.Show();
            Close();
        }

        private void ExitButton_Click(object sender, RoutedEventArgs e)
        {
            dbContext.Dispose();
            Application.Current.Shutdown();
        }

        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            string searchTerm = SearchTextBox.Text.Trim();
            if (string.IsNullOrWhiteSpace(searchTerm))
            {
                MessageBox.Show("Введите поисковый запрос.");
                return;
            }

            Product foundProduct = products.FirstOrDefault(p => p.Name.Equals(searchTerm, StringComparison.OrdinalIgnoreCase));
            if (foundProduct != null)
            {
                products.Remove(foundProduct);
                products.Insert(0, foundProduct);
                RefreshProductList();
            }
            else
            {
                MessageBox.Show("Товар не найден.");
            }
        }
    }
}





