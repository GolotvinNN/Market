﻿using System.Windows;

namespace ProductCatalogApp
{
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            string username = UsernameTextBox.Text;
            string password = PasswordBox.Password;

            if (username == "admin" && password == "admin123")
            {
                AdminWindow adminWindow = new AdminWindow();
                adminWindow.Show();
                Close();
            }
            else if (username == "user" && password == "user123")
            {
                UserWindow userWindow = new UserWindow();
                userWindow.Show();
                Close();
            }
            else
            {
                MessageBox.Show("Неверные учетные данные.");
            }
        }
        private void ExitButton_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

    }
}

