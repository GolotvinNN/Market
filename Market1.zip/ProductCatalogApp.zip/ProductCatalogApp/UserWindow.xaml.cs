﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;

namespace ProductCatalogApp
{
    public partial class UserWindow : Window
    {
        private ProductCatalogDBContext dbContext = new ProductCatalogDBContext();
        private List<Product> products = new List<Product>();

        public UserWindow()
        {
            InitializeComponent();
            LoadProducts();
        }

        private void LoadProducts()
        {
            products = dbContext.GetAllProducts();
            RefreshProductList();
        }

        private void RefreshProductList()
        {
            ProductsListBox.ItemsSource = null;
            ProductsListBox.ItemsSource = products.Select(p => $"{p.Name} - {p.Price}");
        }

        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            string searchTerm = SearchTextBox.Text.Trim();
            if (string.IsNullOrWhiteSpace(searchTerm))
            {
                MessageBox.Show("Введите поисковый запрос.");
                return;
            }

            Product foundProduct = products.FirstOrDefault(p => p.Name.Equals(searchTerm, StringComparison.OrdinalIgnoreCase));
            if (foundProduct != null)
            {
                products.Remove(foundProduct);
                products.Insert(0, foundProduct);
                RefreshProductList();
            }
            else
            {
                MessageBox.Show("Товар не найден.");
            }
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            dbContext.Dispose();
            LoginWindow loginWindow = new LoginWindow();
            loginWindow.Show();
            Close();
        }

        private void ExitButton_Click(object sender, RoutedEventArgs e)
        {
            dbContext.Dispose();
            Application.Current.Shutdown();
        }
    }
}

